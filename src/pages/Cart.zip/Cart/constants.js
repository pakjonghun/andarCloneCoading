export const CARTFUNCS = {
  addCartNumber: 'addCartNumber',
  deleteCheckedItem: 'deleteCheckedItem',
  checkBoxOnClick: 'checkBoxOnClick',
  checkAllBoxOnClick: 'checkAllBoxOnClick',
  getCartCount: 'getCartCount',
  deleteCartById: 'deleteCartById',
};
