import React from 'react';

const CartFuncContext = React.createContext();

export default CartFuncContext;
